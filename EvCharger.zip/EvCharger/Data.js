export const chargers = [
  {
    name: "expressway charging - mariam enterprise",
    id: "a001",
    address: "connaught place, delhi",
    distance: "2102",
    distance_metrics: "metres",
    latitude: "22.4532122",
    longitude: "77.4545322",
    connector_types: ["lvl1dc-2", "lvl2dc-1", "normalac-1"],
  },
];

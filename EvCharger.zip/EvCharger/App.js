import React, { useRef, useState } from "react";
import MapView, { Callout, Circle, Marker } from "react-native-maps";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  FlatList,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import ViewShot from "react-native-view-shot";
import { chargers } from "./Data";

export default function App() {
  const [pin, setPin] = useState({ latitude: 20.5937, longitude: 78.9629 });
  const [imageURI, setImageURI] = useState();
  const ref = useRef();

  const RenderData = ({ item }) => {
    return (
      <ViewShot ref={ref} style={{ flexDirection: "row" }}>
        <View
          style={{
            borderRadius: 10,
            backgroundColor: "black",
            borderColor: "yellow",
            borderWidth: 5,
            paddingHorizontal: 30,
            paddingVertical: 20,
            // padding: 30,
            margin: 20,
            // width: "50%",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              color: "white",
              marginVertical: 4,
              textTransform: "capitalize",
            }}
          >
            {item.name.substring(0, 20)}
          </Text>
          <Text
            style={{
              color: "white",
              fontSize: 12,
              textTransform: "capitalize",
            }}
          >
            {item.address}
          </Text>
          <Text style={{ color: "white", fontSize: 12, marginVertical: 4 }}>
            SUPPPRTED CONNECTORS
          </Text>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[0].substring(0, 6) == "lvl1dc" ? (
                <Text style={{ color: "white" }}>Level 1 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>15kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[0].substring(
                7,
                item.connector_types[0].length
              ) == "2" ? (
                <Text style={{ color: "white" }}>x2</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[1].substring(0, 6) == "lvl2dc" ? (
                <Text style={{ color: "white" }}>Level 2 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>50kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[1].substring(
                7,
                item.connector_types[1].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[2].substring(0, 8) == "normalac" ? (
                <Text style={{ color: "white" }}>Normal AC </Text>
              ) : null}

              <Text style={{ color: "white" }}>3kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[2].substring(
                9,
                item.connector_types[2].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>
        </View>
        {/* 2nd */}

        <View
          style={{
            borderRadius: 10,
            backgroundColor: "black",
            borderColor: "yellow",
            borderWidth: 5,
            paddingHorizontal: 30,
            paddingVertical: 20,
            margin: 20,
            // width: "50%",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              color: "white",
              marginVertical: 4,
              textTransform: "capitalize",
            }}
          >
            {item.name.substring(0, 20)}
          </Text>
          <Text
            style={{
              color: "white",
              fontSize: 12,
              textTransform: "capitalize",
            }}
          >
            {item.address}
          </Text>
          <Text style={{ color: "white", fontSize: 12, marginVertical: 4 }}>
            SUPPPRTED CONNECTORS
          </Text>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[0].substring(0, 6) == "lvl1dc" ? (
                <Text style={{ color: "white" }}>Level 1 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>15kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[0].substring(
                7,
                item.connector_types[0].length
              ) == "2" ? (
                <Text style={{ color: "white" }}>x2</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[1].substring(0, 6) == "lvl2dc" ? (
                <Text style={{ color: "white" }}>Level 2 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>50kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[1].substring(
                7,
                item.connector_types[1].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[2].substring(0, 8) == "normalac" ? (
                <Text style={{ color: "white" }}>Normal AC </Text>
              ) : null}

              <Text style={{ color: "white" }}>3kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[2].substring(
                9,
                item.connector_types[2].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>
        </View>

        <View
          style={{
            borderRadius: 10,
            backgroundColor: "black",
            borderColor: "yellow",
            borderWidth: 5,
            paddingHorizontal: 30,
            paddingVertical: 20,
            margin: 20,
            // width: "50%",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              color: "white",
              marginVertical: 4,
              textTransform: "capitalize",
            }}
          >
            {item.name.substring(0, 20)}
          </Text>
          <Text
            style={{
              color: "white",
              fontSize: 12,
              textTransform: "capitalize",
            }}
          >
            {item.address}
          </Text>
          <Text style={{ color: "white", fontSize: 12, marginVertical: 4 }}>
            SUPPPRTED CONNECTORS
          </Text>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[0].substring(0, 6) == "lvl1dc" ? (
                <Text style={{ color: "white" }}>Level 1 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>15kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[0].substring(
                7,
                item.connector_types[0].length
              ) == "2" ? (
                <Text style={{ color: "white" }}>x2</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[1].substring(0, 6) == "lvl2dc" ? (
                <Text style={{ color: "white" }}>Level 2 DC </Text>
              ) : null}

              <Text style={{ color: "white" }}>50kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[1].substring(
                7,
                item.connector_types[1].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginVertical: 5,
            }}
          >
            <View>
              {item.connector_types[2].substring(0, 8) == "normalac" ? (
                <Text style={{ color: "white" }}>Normal AC </Text>
              ) : null}

              <Text style={{ color: "white" }}>3kW Fast Charging </Text>
            </View>
            <View>
              {item.connector_types[2].substring(
                9,
                item.connector_types[2].length
              ) == "1" ? (
                <Text style={{ color: "white" }}>x1</Text>
              ) : null}
            </View>
          </View>
        </View>
      </ViewShot>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: 20.5937,
          longitude: 78.9629,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        <Marker
          coordinate={pin}
          pinColor="violet"
          draggable={true}
          onDragStart={(e) => {
            console.log("start", e.nativeEvent.coordinate);
          }}
          onDragEnd={(e) => {
            setPin({
              latitude: e.nativeEvent.coordinate.latitude,
              longitude: e.nativeEvent.coordinate.longitude,
            });
          }}
        >
          <Callout>
            <Text>I'm Here!!</Text>
          </Callout>
        </Marker>
        <Circle center={pin} radius={100000} />
      </MapView>
      <View style={{ position: "absolute", top: 50, width: "100%" }}>
        <TextInput
          style={{
            borderRadius: 10,
            margin: 20,
            color: "#000",
            backgroundColor: "black",
            borderColor: "#FFF",
            borderWidth: 1,
            height: 45,
            paddingHorizontal: 20,
            fontSize: 18,
            opacity: 0.75,
            color: "white",
          }}
          placeholder={"Search"}
          placeholderTextColor={"#FFF"}
        />
      </View>

      <TouchableOpacity
        style={{
          borderWidth: 1,
          borderRadius: 10,
          padding: 10,
          position: "absolute",
          top: 150,
          margin: 10,
        }}
        onPress={() => {
          ref.current.capture().then((uri) => {
            console.log("Screen Short Done ", uri);
            setImageURI(imageURI);
          });
        }}
      >
        <Text>Ss</Text>
      </TouchableOpacity>
      <View
        style={{
          position: "absolute",
          bottom: 10,
        }}
      >
        <FlatList
          horizontal={true}
          data={chargers}
          renderItem={RenderData}
          keyExtractor={(item) => item.id}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: {
    width: "100%",
    height: "100%",
    // flex: 1,
  },
});
